from linepy import *
from akad.ttypes import Message
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from gtts import gTTS
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
from tmp.MySplit import *
from random import randint
from shutil import copyfile
from youtube_dl import YoutubeDL
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import time, random, sys, json, null, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#==================    
    
Rezacaem = "DESKTOPMAC\t6.3.1-YOSEMITE-x64\MAC\t10.15.7"
#client = LINE("Fe2OhXFlpOnev4aT6A6c.5ZmsOk+swpflsQP0y0wMta.IPqM1GTPOcQShyUKPqDPQMy2v7gBdbaN//HoafJZNdE=",appName=Rezacaem)
client = LINE("bantengmoza@gmail.com","banteng123")
client.log("Auth Token : "+ str(client.authToken))
oepoll = OEPoll(client)
mid = client.getProfile().mid #new
Bots = [mid] #new
quest = []
temp_flood = {}
admin = "ue73312a0afd258f14b4aaa746345a64c","u091ad9bf0b8f4e27008352ebfb7d4a2e","u0589493aa15df3e9b1ce08a4de2bd17a"

settings = {
    "selfbot":True,
    "restartPoint": False,
    "Sider":{},
    "autoRead": False
}

wait = {
    "selfbot":True
}

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}
cctv = {
    "cyduk":{},
    "point":{},
    "MENTION":{},
    "sidermem":{}
}

def Remotereza(to, Bots):
    try:
        AbdulMuid = ""
        Muid = "1. ".format(str(len(Bots)))
        Zunita = []
        Abdul = 1
        Rezaganteng = 2
        for Sedot in Bots:
            Muids = "@projecreza\n"
            Wikwik = str(len(Muid))
            Ngentot = str(len(Muid) + len(Muids) - 1)
            AbdulMuid = {'S':Wikwik, 'E':Ngentot, 'M':Sedot}
            Zunita.append(AbdulMuid)
            Muid += Muids
            if Abdul < len(Bots):
                Abdul += 1
                Muid += "%i. " % (Rezaganteng)
                Rezaganteng=(Rezaganteng+1)
            else:
                try:
                    Abdul = "\n{} ".format(str(client.getGroup(to).name))
                except:
                    Abdul = "\n[ Success ]"
        client.sendMessage(to, Muid, {'MENTION': str('{"MENTIONEES":' + json.dumps(Zunita) + '}')}, 0)
    except Exception as error:
        logError(error)
        
try:
    with open("data.json", "r", encoding="utf_8_sig") as fp:
        data = json.loads(fp.read())
except:
    print ("data file not found, data dict default will used")
    data = {}

with open("quest.txt", "r") as file:
     blist = file.readlines()
     quest = [x.strip() for x in blist]
file.close()
group = client.getGroupIdsJoined()

for g in group:
  data[g]={"point":{}}
  data[g]["saklar"]=False
  data[g]["quest"]=""
  data[g]["asw"]=[]
  data[g]["tmp"]=[]

def backupData():
    with open("data.json", "w", encoding="utf8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4, separators=(",", ": "))
atexit.register(backupData)

def myhelp():
    helpMessage = "╭[ ᴅᴀғᴛᴀʀ ᴘᴇʀɪɴᴛᴀʜ ]" + "\n" + \
                  "│‣ ᴍᴜʟᴀɪ" + "\n" + \
                  "│‣ʀᴇsᴇᴛ" + "\n" + \
                  "│‣ɴᴇxᴛ" + "\n" + \
                  "│‣ɴʏᴇʀᴀʜ" + "\n" + \
                  "│‣ᴋᴇʟᴜᴀʀ" + "\n" + \
                  "│‣ʟᴀᴘᴏʀᴋᴀɴ" + "\n" + \
                  "╰[  ᴄᴀɴᴛɪᴋᴀ ɢᴀᴍᴇs  ]"
    return helpMessage

def getQuest(to):
	try:
			data[to]["quest"] = ""
			data[to]["asw"] = []
			data[to]["tmp"] = []
			a = random.choice(quest)
			a = a.split("*")
			data[to]["quest"] = a[0]
			for i in range(len(a)):
				data[to]["asw"] += [a[i]]
			data[to]["asw"].remove(a[0])
			for j in range(len(data[to]["asw"])):
				data[to]["tmp"] += [str(j+1)+". _________"]
	except Exception as e:
		print(e)
#######SEND MENTION TAG NAMA########### 
def sendMention(to, mid, firstmessage="", lastmessage=""):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@projecreza "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {"S":slen, "E":elen, "M":mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        client.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        print(error)
#==============CCTV==============#
def mentionMembers(to, mid):
    try:
        arrData = ""
        textx = "".format(str(len(mid)))
        arr = []
        no = 1
        for i in mid:
            mention = "@projecreza\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += ""
            else:
                try:
                    textx += "".format(str(client.getGroup(to).name))
                except:
                    pass
        client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        logError(error)
        client.sendMessage(to, "[ INFO ] Error :\n" + str(error))
        
def delExpire():
    if temp_flood != {}:
        for tmp in temp_flood:
            if temp_flood[tmp]["expire"] == True:
                if time.time() - temp_flood[tmp]["time"] >= 3*10:
                    temp_flood[tmp]["expire"] = False
                    temp_flood[tmp]["time"] = time.time()
                    try:
                        client.sendMessage(tmp, "ᴄᴀɴᴛɪᴋᴀ ᴋᴜɪs ᴋᴇᴍʙᴀʟɪ ᴀᴋᴛɪғ")
                    except Exception as error:
                        print(error)
                        
def restart_program():
	backupData()
	time.sleep(5)
	python = sys.executable
	os.execl(python, python, * sys.argv)
	
def restart_bot():   #new
    python = sys.executable
    os.execl(python, python, *sys.argv)

def clientBot(op):
    try:
        if op.type == 0:
            print ("[0] END OF OPERATION")
            return
#------------------READ CCTV--------------------
        if op.type == 55:
            print ("[ 55 ] NOTIFIED READ MESSAGE")
            try:
                if cctv['cyduk'][op.param1]==True:
                    if op.param1 in cctv['point']:
                        Name = client.getContact(op.param2).displayName
                        if Name in cctv['sidermem'][op.param1]:
                            pass
                        else:
                            cctv['sidermem'][op.param1] += "\nâ¢ " + Name
                            if " " in Name:
                                nick = Name.split(' ')
                                if len(nick) == 2:
                                    client.sendMessage(op.param1, " Hallo kak " + nick[0] + " Sini Gabung chat jangan cctv ae")
                                    time.sleep(0.2)
                                    mentionMembers(op.param1,[op.param2])
                                else:
                                    client.sendMessage(op.param1, "ciluppp baaa " + nick[1] + " Nɢɪɴᴛɪᴘ ᴍᴇʟᴜʟᴜ, ᴍᴇɴᴅɪɴɢ sɪɴɪ , ᴋɪᴛᴀ ɴɢᴇʀᴜᴍᴘɪ ")
                                    time.sleep(0.2)
                                    mentionMembers(op.param1,[op.param2])
                            else:
                                client.sendMessage(op.param1, " Nah kan " + Name + " Kᴇᴛᴀᴜᴡᴀɴ ɴɢɪɴᴛɪᴘ Hᴀʜᴀʜᴀ.")
                                time.sleep(0.2)
                                mentionMembers(op.param1,[op.param2])
                    else:
                        pass
                else:
                    pass
            except:
                pass
#------------------NOTIFIED_INVITE_INTO_ROOM-------------
        if op.type == 22:
            client.leaveRoom(op.param1)
            print ("[22] NOTIFIED INVITE INTO ROOM")
#--------------------INVITE_INTO_ROOM--------------------
        if op.type == 21:
            client.leaveRoom(op.param1)
            print ("[21] NOTIFIED INVITE INTO ROOM")
        if op.type == 5:
            print ("[5] NOTIFIED ADD CONTACT")
            client.findAndAddContactsByMid(op.param1)
            client.sendMessage(op.param1, "ʜᴀʟʟᴏ {}, ᴛᴇʀɪᴍᴀᴋᴀsɪʜ ᴛᴇʟᴀʜ ᴍᴇɴᴀᴍʙᴀʜᴋᴀɴ sᴀʏᴀ sᴇʙᴀɢᴀɪ ᴛᴇᴍᴀɴ 🙏\nᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ᴀᴅᴅ ᴄᴇᴏ ʙᴏᴛɴʏᴀ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ :".format(str(client.getContact(op.param1).displayName)))
            client.sendContact(op.param1, "ue73312a0afd258f14b4aaa746345a64c")
        if op.type == 13:
            print ("[13] NOTIFIED INVITE INTO GROUP")
            group = client.getGroup(op.param1)
            contact = client.getContact(op.param2)
            if clientMID in op.param3:
            	client.acceptGroupInvitation(op.param1)
            	client.sendMessage(op.param1, "ʜᴀʟᴏ ᴋᴀᴋ, ᴛᴇʀɪᴍᴀ ᴋᴀsɪʜ ᴛᴇʟᴀʜ ᴍᴇɴɢᴜɴᴅᴀɴɢ sᴀʏᴀ 🙏")
            	client.sendMessage(op.param1, "ᴋᴇᴛɪᴋ ʜᴇʟᴘ ᴅɪ ɢʀᴏᴜᴘ ɪɴɪ ᴜɴᴛᴜᴋ ʙᴀɴᴛᴜᴀɴ")
            	data[op.param1] = {
                        "point": {},
                        "saklar": False,
                        "quest": "",
                        "tmp": [],
                        "asw": []
                }
                
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != client.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
                if settings["autoRead"] == True:
                    client.sendChatChecked(to, msg_id)
                if to in read["readPoint"]:
                    if sender not in read["ROM"][to]:
                        read["ROM"][to][sender] = True
                
        if op.type in [26, 25]:
            if op.type == 26: print ("[26] RECEIVE MESSAGE")
            else: print ("[25] SEND MESSAGE")
            msg = op.message
            text = msg.text
            receiver = msg.to
            sender = msg._from
            to = receiver
            try:
                if msg.contentType == 0:
                    if msg.toType == 2:
                    	contactlist = client.getAllContactIds()
                    	kontak = [cont.mid for cont in client.getContacts(contactlist)]
                    	for i in range(len(data[to]["asw"])):
                            if text.lower() == data[to]["asw"][i].lower() and sender not in clientMID and data[to]["saklar"] == True:
                                if sender in kontak:
                                    wnr = client.getContact(sender).displayName
                                    wna = client.getContact(sender)
                                    if wnr in data[to]["point"]:
                                        data[to]["point"][wnr] += 1
                                    else:
                                        data[to]["point"][wnr] = 1
                                    if i != len(data[to]["asw"]):
                                        data[to]["tmp"][i] = str(i+1)+". "+data[to]["asw"][i]+" (1)"+" ["+wnr+"]"
                                        data[to]["asw"][i] = data[to]["asw"][i]+" (*)"
                                    else:
                                        data[to]["tmp"].remove(str(data[to]["tmp"][i]))
                                        data[to]["tmp"].append(str(i+1)+". "+data[to]["asw"][i]+" (1)"+" ["+wnr+"]")
                                        data[to]["asw"].remove(str(data[to]["asw"][i]))
                                        data[to]["tmp"].append(data[to]["asw"][i]+" (*)")
                                    rsl,rnk = "",""
                                    for j in data[to]["tmp"]:
                                        rsl += j+"\n"
                                    for k in data[to]["point"]:
                                        rnk += "│➥ "+k+" : "+str(data[to]["point"][k])+"\n"
                                    if "_________" in str(data[to]["tmp"]):
                                        isi = str(data[to]["quest"])+"\n"+rsl
                                        client.sendMessage(to, isi)
                                    else:
                                        data[to]["saklar"] = False
                                        isi = str(data[to]["quest"])+"\n"+rsl
                                        client.sendMessage(to, isi)
                                        client.sendMessage(to, "╭‣ ᴘᴀᴘᴀɴ sᴄᴏʀᴇ ᴘᴏɪɴ :\n"+rnk)
                                        client.sendMessage(to, "ᴋᴇᴛɪᴋ ᴍᴜʟᴀɪ ᴜɴᴛᴜᴋ ᴘᴇʀᴛᴀɴʏᴀᴀɴ ʟᴀɪɴɴʏᴀ")
                                else:
                                    sendMention(to, sender, "", " ᴋᴀᴋᴀᴋ ʙᴇʟᴜᴍ ᴍᴇɴᴀᴍʙᴀʜᴋᴀɴ ᴄᴀɴᴛɪᴋᴀ ᴋᴜɪs sᴇʙᴀɢᴀɪ ᴛᴇᴍᴀɴ, ᴜɴᴛᴜᴋ ɪᴋᴜᴛ ʙᴇʀᴘᴀʀᴛɪsɪᴘᴀsɪ sɪʟᴀʜᴋᴀɴ ᴛᴀᴍʙᴀʜᴋᴀɴ ᴄᴀɴᴛɪᴋᴀ ᴋᴜɪs sᴇʙᴀɢᴀɪ ᴛᴇᴍᴀɴ ᴅᴜʟᴜ ᴋᴀᴋ ^_^")
            except Exception as e:
                client.log("[RECEIVE_MESSAGE] ERROR : " + str(e))
                traceback.print_tb(e.__traceback__)
            if msg.toType == 0 and sender != clientMID:
                to = sender
            else:
            	to = receiver
            if receiver in temp_flood:
                if temp_flood[receiver]["expire"] == True:
                    if temp_flood[receiver]["expire"] >= 20:
                        temp_flood[receiver]["expire"] = False
                        temp_flood[receiver]["time"] = time.time()
                        client.sendMessage(to, "ᴄᴀɴᴛɪᴋᴀ ɢᴀᴍᴇs ᴋᴇᴍʙᴀʟɪ ᴀᴋᴛɪғ")
                    return
                elif time.time() - temp_flood[receiver]["time"] <= 5:
                    temp_flood[receiver]["flood"] += 1
                    if temp_flood[receiver]["flood"] >= 20:
                        temp_flood[receiver]["flood"] = 0
                        temp_flood[receiver]["expire"] = True
                        ret_ = "sᴘᴀᴍ ᴛᴇʀᴅᴇᴛᴇᴋsɪ, ᴄᴀɴᴛɪᴋᴀ ᴋᴜɪs ᴀᴋᴀɴ sɪʟᴇɴᴛ sᴇʟᴀᴍᴀ 30 ᴅᴇᴛɪᴋ ᴘᴀᴅᴀ ʀᴜᴀɴɢᴀɴ ɪɴɪ ᴀᴛᴀᴜ ᴋᴇᴛɪᴋ ᴏᴘᴇɴ ᴜɴᴛᴜᴋ ᴍᴇɴɢᴀᴋᴛɪғᴋᴀɴ ᴋᴇᴍʙᴀʟɪ"
                        client.sendMessage(to, str(ret_))
                else:
                     temp_flood[receiver]["flood"] = 0
                     temp_flood[receiver]["time"] = time.time()
            else:
                temp_flood[receiver] = {
    	            "time": time.time(),
    	            "flood": 0,
    	            "expire": False
                }
            if text is None: return
            if text.lower() == "mulai" and sender not in clientMID:
                if data[to]["saklar"] == False:
                    data[to]["saklar"] = True
                    getQuest(to)
                    aa = ""
                    for aswr in data[to]["tmp"]:
                        aa += aswr+"\n"
                        q = data[to]["quest"]+"\n"+aa
                    client.sendMessage(to, q)
                else:
                    aa = "" 
                    for aswr in data[to]["tmp"]:
                        aa += aswr+"\n"
                    q = data[to]["quest"]+"\n"+aa
                    client.sendMessage(to, q)
                    client.sendMessage(to, "ᴋᴇᴛɪᴋ ɴʏᴇʀᴀʜ ᴜɴᴛᴜᴋ ᴍᴇɴɢᴀᴋʜɪʀɪ ᴘᴇʀᴛᴀɴʏᴀᴀɴ ɪɴɪ")
                               
            elif text.lower() == "nyerah" and sender in admin:
                if data[to]["saklar"] == True:
                    rnk,asd = "",""
                    data[to]["saklar"] = False
                    for j in range(len(data[to]["tmp"])):
                        if "_________" in data[to]["tmp"][j]:
                            if j != len(data[to]["tmp"]):
                                data[to]["tmp"][j] = str(j+1)+". "+data[to]["asw"][j]+" (*system)"
                            else:
                                data[to]["tmp"][j].remove(str(data[to]["tmp"][j]))
                                data[to]["tmp"][j].append(str(j+1)+". "+data[to]["asw"][j]+" (*system)")
                    for m in data[to]["tmp"]:
                        asd += m+"\n"
                    for k in data[to]["point"]:
                        rnk += "│➥ "+k+" : "+str(data[to]["point"][k])+"\n"
                    client.sendMessage(to, str(data[to]["quest"])+"\n"+asd)
                    client.sendMessage(to, "╭‣ ᴘᴀᴘᴀɴ sᴄᴏʀᴇ ᴘᴏɪɴ :\n"+rnk)
                    client.sendMessage(to, "ᴋᴇᴛɪᴋ ᴍᴜʟᴀɪ ᴜɴᴛᴜᴋ ᴘᴇʀᴛᴀɴʏᴀᴀɴ ʟᴀɪɴɴʏᴀ")
                else:
                    client.sendMessage(to, "ɢᴀᴍᴇ ʙᴇʟᴜᴍ ᴅɪ ᴍᴜʟᴀɪ, ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴍᴇɴʏᴇʀᴀʜ.")
                    client.sendMessage(to, "ᴋᴇᴛɪᴋ ᴍᴜʟᴀɪ ᴜɴᴛᴜᴋ ᴍᴇᴍᴜʟᴀɪ ᴘᴇʀᴍᴀɪɴᴀɴ.")
            elif text.lower() == "nyerah" and sender not in clientMID:
                   client.sendMessage(to, "ᴍᴀᴀғ ᴋᴀᴋᴀᴋ ғɪᴛᴜʀ ɴʏᴇʀᴀʜ ᴅɪʜɪʟᴀɴɢᴋᴀɴ ᴅᴜʟᴜ, ғɪᴛᴜʀ ɴʏᴇʀᴀʜ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴏʟᴇʜ ᴀᴅᴍɪɴ")     
                   client.sendMessage(to, "ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ᴅɪʙᴀᴡᴀʜ ɪɴɪ ᴋᴀᴋ ᴊɪᴋᴀ ᴀᴅᴀ ᴘᴇʀᴛᴀɴʏᴀᴀɴ")
                   client.sendContact(to, "u091ad9bf0b8f4e27008352ebfb7d4a2e")
            elif text.lower() == "next" and sender not in clientMID:
            	if data[to]["saklar"] == True:
            		getQuest(to)
            		aa = ""
            		for aswr in data[to]["tmp"]:
            			aa += aswr+"\n"
            			q = data[to]["quest"]+"\n"+aa
            		client.sendMessage(to, q)
            	else:
            		client.sendMessage(to, "ᴘᴇʀᴍᴀɪɴᴀɴ ʙᴇʟᴜᴍ ᴅɪ ᴍᴜʟᴀɪ, ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ʙᴇʀᴘɪɴᴅᴀʜ ᴋᴇ sᴏᴀʟ ʙᴇʀɪᴋᴜᴛɴʏᴀ")
            elif text.lower() == "/reset" and sender in admin:
                data[to]["point"] = {}
                data[to]["saklar"] = False
                client.sendMessage(to, "ᴘᴇʀᴍᴀɪɴᴀɴ ᴛᴇʟᴀʜ ᴅɪ ʀᴇsᴇᴛ")
                client.sendMessage(to, "ᴋᴇᴛɪᴋ ᴍᴜʟᴀɪ ᴜɴᴛᴜᴋ ᴍᴇᴍᴜʟᴀɪ ᴘᴇʀᴍᴀɪɴᴀɴ")
            elif text.lower() == "nyerah" and sender not in clientMID:
                   client.sendMessage(to, "ᴍᴀᴀғ ᴋᴀᴋᴀᴋ ғɪᴛᴜʀ ʀᴇsᴇᴛ ᴅɪʜɪʟᴀɴɢᴋᴀɴ ᴅᴜʟᴜ, ғɪᴛᴜʀ ʀᴇsᴇᴛ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴏʟᴇʜ ᴀᴅᴍɪɴ")     
                   client.sendMessage(to, "ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ᴅɪʙᴀᴡᴀʜ ɪɴɪ ᴋᴀᴋ ᴊɪᴋᴀ ᴀᴅᴀ ᴘᴇʀᴛᴀɴʏᴀᴀɴ")
                   client.sendContact(to, "u091ad9bf0b8f4e27008352ebfb7d4a2e")
            elif text.lower() == "read" and sender in admin:
                   settings["autoRead"] = True
                   client.sendMessage(to, "➸ aυтo ndelok on")
            elif text.lower() == "readoff" and sender in admin:
                   settings["autoRead"] = False
                   client.sendMessage(to, "➸ aυтo ndelok oғғ")
            elif text.lower() == "/keluar" and sender  in admin:
                if msg.toType == 2:
                    if data[to]["saklar"] == True:
                        client.sendMessage(to, "ɢᴀᴍᴇ ʙᴇʟᴜᴍ ᴅɪ sᴇʟᴇsᴀɪᴋᴀɴ, ᴋᴇᴛɪᴋ ɴʏᴇʀᴀʜ ᴜɴᴛᴜᴋ ᴍᴇɴʏᴇʟᴇsᴀɪᴋᴀɴ ɢᴀᴍᴇ ᴅᴀɴ ʙᴏᴛ ᴀᴋᴀɴ ᴋᴇʟᴜᴀʀ 🙏")
                    else:
                        client.sendMessage(to, "ᴏᴋᴇ, sᴇᴇ ʏᴏᴜ ɴᴇxᴛ ᴛɪᴍᴇ ᴋᴀᴋ 🙏")
                        client.leaveGroup(to)
            elif text.lower() == "/laporkan" and sender in admin:
                client.sendMessage(to, "ᴜɴᴛᴜᴋ ᴍᴇʟᴀᴘᴏʀᴋᴀɴ ᴍᴀsᴀʟᴀʜ ʏᴀɴɢ ᴅɪ ᴀʟᴀᴍɪ ᴀᴛᴀᴜ ɪɴɢɪɴ ᴍᴇᴍʙᴇʀɪᴋᴀɴ sᴀʀᴀɴ, ᴋᴀʟɪᴀɴ ʙɪsᴀ ʟᴀɴɢsᴜɴɢ ᴍᴇɴɢʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ᴍᴇʟᴀʟᴜɪ ᴋᴏɴᴛᴀᴋ ᴅɪʙᴀᴡᴀʜ ɪɴɪ :")
                client.sendContact(to, "ue73312a0afd258f14b4aaa746345a64c")
                
            elif text.lower() ==  "gl" and sender in admin: #new
                   ma = ""
                   a = 0
                   gid = client.getGroupIdsJoined()
                   for i in gid:
                       G = client.getGroup(i)
                       a = a + 1
                       end = "\n"
                       ma += "┝➲ " + str(a) + ". " +G.name+ "\n"
                   client.sendMessage(msg.to,"╭━━━[ ʟɪsᴛ ɢʀᴏᴜᴘ ]\n┝\n"+ma+"┝\n╰━━[ ᴛᴏᴛᴀʟ「"+str(len(gid))+"」ɢʀᴏᴜᴘs ]")
                   
            elif text.lower() ==  "sp" and sender in admin: #new
                   start = time.time()
                   client.sendMessage(msg.to, "💿[ʟᴏᴀᴅɪɴɢ] sᴘᴇᴇᴅ...!!!")
                   elapsed_time = time.time() - start
                   took = time.time() - start
                   a = "ᴋᴇᴄᴇᴘᴀᴛᴀɴ : %.3f ᴅᴇᴛɪᴋ ʙᴏssǫɪᴜ" % (took)
                   client.sendMessage(to, str(a))

            elif text.lower() == "id" and sender:         #new
                   contact = client.getContact(msg._from)
                   xname = contact.displayName
                   reza = "Nama: "+ xname + "\nMid: " + msg._from+"\nStatus: {}".format(contact.statusMessage)
                   client.sendMessage(to, str(reza))
                   
            elif text.lower() == "urip" and sender in admin:   #new
                   wait["selfbot"] = True
                   client.sendMessage(to, "on bot ʙᴏssǫɪᴜ")
            elif text.lower() == "modar" and sender in admin:         #new
                   wait["selfbot"] = False
                   client.sendMessage(to, "off bot ʙᴏssǫɪᴜ")
            elif text.lower() == "help" and sender not in clientMID:
                helpMessage = myhelp()
                client.sendMessage(to, str(helpMessage))
            elif text.lower() == "restart" and sender in admin:
                client.sendMessage(to, "sᴜᴋsᴇs ᴍᴇʀᴇsᴛᴀʀᴛ ʙᴏᴛ ʙᴏssǫɪᴜ")
                restart_program()
                client.sendMessage(to, str(helpMessage))
            elif text.lower() == "recall" and sender in admin: #new
                reza = "ʀᴇsᴛᴀʀᴛ ʙᴏᴛ"
                client.sendMessage(to, str(reza))
                wait["restartPoint"] = msg.to
                restart_bot()
                client.sendMessage(msg.to, "ᴅᴏɴᴇ ʙᴏs")
                            
            elif text.lower().startswith("add ") and sender in admin:
            	targets = []
            	key = eval(msg.contentMetadata["MENTION"])
            	key["MENTIONEES"] [0] ["M"]
            	for x in key["MENTIONEES"]:
            		targets.append(x["M"])
            	for target in targets:
            		try:
            			client.findAndAddContactsByMid(target)
            			client.sendMessage(to, "ᴅᴏɴᴇ √")
            		except Exception as error:
            			client.sendMessage(to, str(error))        
                
            elif text.lower().startswith("reza: ") and sender in admin: #new
                    Croot = msg.text.split(":")
                    Pepek = msg.text.replace(Croot[0] + ":"," ")
                    Peler = client.getGroupIdsJoined()
                    Pokeh = Peler[int(Pepek)-1]                                                            
                    Muidreza = client.getGroup(Pokeh)                                                            
                    Muid = [contact.mid for contact in Muidreza.members]
                    Celik = len(Muid)//20
                    for Manik in range(Celik+1):
                        txt = u''
                        s=0
                        Bohay=[]
                        for Jilat in Muidreza.members[Manik*20 : (Manik+1)*20]:
                            Bohay.append(Jilat.mid)
                        Remotereza(Pokeh, Bohay)
        #########====={ command sider } =======#########
            elif text.lower() == "📹" and sender in admin:
                try:
                    del cctv['point'][msg.to]
                    del cctv['sidermem'][msg.to]
                    del cctv['cyduk'][msg.to]
                except:
                    pass
                cctv['point'][msg.to] = msg.id
                cctv['sidermem'][msg.to] = ""
                cctv['cyduk'][msg.to]=True 
                settings["Sider"] = True
                client.sendMessage(msg.to,"ceĸ ѕιder on")

            elif text.lower() == "inoff" and sender in admin:
                if msg.to in cctv['point']:
                   cctv['cyduk'][msg.to]=False
                   settings["Sider"] = False
                   client.sendMessage(msg.to,"ceĸ ѕιder oғғ")
                else:
                    client.sendMessage(msg.to,"ceĸ ѕιder oғғ")
            elif text.lower() == "pell" and sender in admin: #new
              if wait["selfbot"] == True:
                client.removeAllMessages(op.param2)
                client.sendMessage(msg.to, "ᴅᴏɴᴇ ʙᴏs")
      ############AUTO RESPON SAPAM DLL############
            elif 'ssal' in msg.text and sender not in clientMID: #new
                sendMention(to, sender, "", "waalaikumsalam kak")
            elif text.lower() == "naik" and sender not in clientMID: #new
              if wait["selfbot"] == True:
                sendMention(to, sender, "", "jngn bang diatas banyak yg menggatal 😂")
            elif text.lower() == "dudul" and sender not in clientMID:  #new
              if wait["selfbot"] == True:
                sendMention(to, sender, "", "Udah gawan lahir brohh 😔")
            elif text.lower() == "asem" and sender not in clientMID: #new
              if wait["selfbot"] == True:
                sendMention(to, sender, "", "lah bukannya lu yg ga  pernah mandi coy jadi bauk acem 😛")
            elif "debah" in msg.text and sender not in clientMID: #new 
              if wait["selfbot"] == True:
                sendMention(to, sender, "", "wanjer bukannya lu ya bedebah yg sesungguhnya 😑")
            elif text.lower() == "sange" and sender not in clientMID:  #new
              if wait["selfbot"] == True:
                sendMention(to, sender, "", "wanjir bisa-bisanya lu ya  sange dimari astajimm paok 😔")
            elif "naik" in msg.text and sender not in clientMID: #new
              if wait["selfbot"] == True:
                sendMention(to, sender, "", "mending jngn lah, diatas ngeri dul 😂")
            elif "suek" in msg.text and sender not in clientMID:  #new
              if wait["selfbot"] == True:
                sendMention(to, sender, "", "Sini tak jahit biar gak suekk sempvakmu tong 😔")
            elif text.lower() == "typo" and sender not in clientMID:  #new
              if wait["selfbot"] == True:
                sendMention(to, sender, "", "lak typo ganti ae jempol kuda")
            elif "ypo" in msg.text and sender not in clientMID:  #new
              if wait["selfbot"] == True:
                sendMention(to, sender, "", "jempolmu kurang gedi gantinen karo jempol jerapah")
            elif text.lower() == "mih" and sender not in clientMID:  #new
              if wait["selfbot"] == True:
                sendMention(to, sender, "", "rasah celak celok nduk")
            elif "mlm" in msg.text and sender not in clientMID:  #new
              if wait["selfbot"] == True:
                sendMention(to, sender, "", "masih siang dul")
            elif "kkww" in msg.text and sender not in clientMID:  #new
              if wait["selfbot"] == True:
                sendMention(to, sender, "", "guyumu loh elek men astaga 😁")
            elif "maem" in msg.text and sender not in clientMID:  #new
              if wait["selfbot"] == True:
                sendMention(to, sender, "", "bagi dunk biar kuat, kokoh dan tahan lama")

    except Exception as e:
    	client.log("[RECEIVE_MESSAGE] ERROR : " + str(e))
    	traceback.print_tb(e.__traceback__)

def run():
    while True:
        try:
        	delExpire()
        	ops = oepoll.singleTrace(count=50)
        	if ops != None:
        		for op in ops:
        			thread = Thread(target=clientBot(op))
        		#	thread.daemon = daemon
        			thread.start()
        			oepoll.setRevision(op.revision)
        except Exception as e:
        	print(e)

if __name__ == "__main__":
    run()
